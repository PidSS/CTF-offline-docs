<?php
/*
Plugin Name: CSRF防御插件
Version: 1.1
Description: 对危险操作做一定防御，防止CSRF漏洞的发生。
Author: phithon
Author Email: root@leavesongs.com
Author URL: http://www.leavesongs.com
*/
!defined('EMLOG_ROOT') && exit('hello hacker');
$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
$audit = false;
$safe_handle = array(
	'del',
	'delbyip',
	'dellink',
	'renewdata',
	'del_attach',
	'delicon',
	'reset',
	'inactive',
	'new',
	'install',
	'instpl',
	'insplu'
);
if (isset($_GET['action']) && in_array($_GET['action'], $safe_handle)) {
	$audit = true;
}
if (ROLE != 'visitor' && (!empty($_POST) || $audit)):
	if (empty($referer)) {
		csrf_defence_error($audit);
	}
	$referarr = parse_url($referer);
	$blogarr = parse_url(BLOG_URL);
	if ($referarr['host'] != $blogarr['host']) {
		csrf_defence_error($audit);
	}
endif;

function csrf_defence_error($audit)
{ ?>

<!DOCTYPE html>
<html>
<head>			
<title>CSRF防御系统 - 帮助您远离黑客们</title>
<meta charset="utf-8" />
<style type="text/css">
body {
  background-color:#F7F7F7;
  font-family: Arial;
  font-size: 12px;
  line-height:150%;
}
.main {
  background-color:#FFFFFF;
  font-size: 12px;
  color: #666666;
  width:650px;
  margin:60px auto 0px;
  border-radius: 10px;
  padding:30px 10px;
  list-style:none;
  border:#DFDFDF 1px solid;
}
.main p {
  line-height: 18px;
  margin: 5px 20px;
}
</style>
</head>
<body>
<div class="main">
<h2>小心，您可能正受到CSRF攻击</h2>
看到此页面说明您可能正受到黑客的CSRF攻击，请不要点击陌生链接。如果您确定不是，请禁用本插件，本插件可能与其他插件或您的浏览器有冲突。
本页面仅管理员与作者可见，不必担心SEO等影响。
<?php 
if ($audit):
	echo "<p><a href='http://" . $_SERVER['SERVER_NAME'] . $_SERVER["REQUEST_URI"] . "'>我还是愿意继续访问</a></p>";
endif;
?>
<br/><br/>有关更多信息，请联系www.leavesongs.com<br/><br/>
<input type="button" style="width:30%" value="<< 返回首页" onclick="location.href='<?php echo BLOG_URL;?>'">
<br/><br/><small>Defence by phithon</a>&nbsp;And&nbsp;<a href="http://www.leavesongs.com" target="_blank">离别歌</a></small>
</div>
</body></html>
<?
	exit;
}