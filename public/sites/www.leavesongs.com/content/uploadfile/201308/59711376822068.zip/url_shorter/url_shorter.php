<?php
/*
Plugin Name: 评论链接自动短域
Version: 1.1
Plugin URL:
Description: 访客评论后留下的链接自动生成短域名
Author: phithon
Author URL: http://www.leavesongs.com
*/
!defined('EMLOG_ROOT') && exit('access deined!');

addAction('comment_saved', 'url_shorter_main');

function url_shorter_main($cid){
	$db = MySql::getInstance();
	$url = $db->once_fetch_array('SELECT url FROM '.DB_PREFIX."comment WHERE cid = '{$cid}'");
	if (function_exists('curl_init')) {
		$new = url_shorter_getUrl($url['url']);
	} else {
		$new = url_shorter_getFile($url['url']);
	}
	$db->query('UPDATE '.DB_PREFIX."comment SET url = '{$new}' WHERE cid='{$cid}'");
}

//如果支持curl模块则使用该模块获得短域名
function url_shorter_getUrl($old_url){
	$url="http://qitadwz.duapp.com/_app.php?type=text&url=".urlencode($old_url);
	$ch = curl_init();
	$timeout = 5;
	curl_setopt ($ch, CURLOPT_URL, $url);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$file_contents = curl_exec($ch);
	if (false === $file_contents || !url_shorter_isUrl($file_contents)) {
		return $old_url;
	}
	curl_close($ch);
	return $file_contents;
}

//如果不支持curl模块则使用file_get_contents获得短域名
function url_shorter_getFile($old_url){
	$url = file_get_contents("http://qitadwz.duapp.com/_app.php?type=text&url=".urlencode($old_url));
	if (false === $url || !url_shorter_isUrl($url)) {
		return $old_url;
	} else {
		return $url;
	}
}

//判断是否获取的是一个网址
function url_shorter_isUrl($url){
	$pattern = '/^http:\/\/[^\s]*$/';
	return preg_match($pattern, $url);
}