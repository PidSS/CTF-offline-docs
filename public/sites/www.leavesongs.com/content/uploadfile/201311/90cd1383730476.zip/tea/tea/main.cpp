#include "tea.h"
#include "util.h"
#include "md5.h"
#include <iostream>
#include <ctime>

using namespace std;
#define random(x) (rand()%x)
#define TIMES 64

bool encrypt(const string src, const string strKey, string& dest);
bool decode(const string src, const string strKey, string& dest);
void usage();
void cmdLoop();

int main(int argc, char * argv[]) {
	cmdLoop();
	return 0;
}

void cmdLoop()
{
	string strCrypt, strSrc, strPlain, strKey, strMethod;
	usage();
	while (true)
	{
		cout << "Method > ";
		cin >> strMethod;
		cout << "Key > ";
		cin >> strKey;
		byte bMd5[64];
		char strMd5[36];
		librad_md5_calc(bMd5, (byte *)(strKey.c_str()), strKey.length());
		hex_dump(bMd5, 16, strMd5);
		const string keyStr(strMd5);
		if ("e" == strMethod)
		{
			cout << "Src > ";
			cin >> strSrc;
			encrypt(strSrc, keyStr, strCrypt);
			cout << "PLAIN > " << strCrypt <<endl << endl;
		} 
		else if("d" == strMethod)
		{
			cout << "Encrypted message > ";
			cin >> strCrypt;
			decode(strCrypt, keyStr, strPlain);
			cout << "ENCRYPT��" << strPlain << endl << endl;
		}else{
			cout << "e for encode and d for decode" << endl << endl; 
		}
	}

	return ;
}

//tea
bool decode(const string src, const string strKey, string& dest)
{
	int rlen = src.at(0) - '0';
	string enc = src.substr(1), strOut = "";
	int len = enc.length(), i;
	const int SIZE_IN = 16, SIZE_OUT = 8, SIZE_KEY = 16;
	byte plain[SIZE_IN] = {0}, crypt[SIZE_OUT] = {0}, key[SIZE_KEY] = {0};

	for (i = 0 ; i < len ; i += SIZE_IN)
	{
		string strNow = enc.substr(i, SIZE_IN);
		size_t size_in = hexStringToBytes(strNow, crypt);
		size_t size_key = hexStringToBytes(strKey, key);

		if (size_in != SIZE_IN / 2 || size_key != SIZE_KEY)
			return false;

		TEA tea(key, TIMES, false);
		tea.decrypt(crypt, plain);
		if (i >= len - SIZE_IN && rlen != 0)
		{
			strOut += byteToString(plain, rlen);
			//strOut += bytesToHexString(plain, rlen);
		}else{
			strOut += byteToString(plain, SIZE_OUT);
			//strOut += bytesToHexString(plain, SIZE_OUT);
		}
	}//
	dest = strOut;
	return true;
}
//14D9D9C154EF0F936CDF177BB910BA877E63A4E34CE7CBEDF
bool encrypt(const string src, const string strKey, string& dest)
{
	string strCrypt("");
	srand((unsigned)time(0));
	const int SIZE_IN = 8, SIZE_OUT = 8, SIZE_KEY = 16;
	byte plain[SIZE_IN], crypt[SIZE_OUT], key[SIZE_KEY];
	int len = src.length();
	for (size_t i = 0 ; i < len ; i += 8)
	{
		string strNow;
		if (len - i < 8)
		{	
			strNow = src.substr(i);
			int remain = 8 - (len - i);
			for (size_t j = 0 ; j < remain ; j++)
			{
				char c = random(128)&0xff;
				strNow += c;
			}
		}else{
			strNow = src.substr(i, 8);
		}
		size_t size_in = stringToBytes(strNow, plain);
		size_t size_key = hexStringToBytes(strKey, key);

		if (size_in != SIZE_IN || size_key != SIZE_KEY)
			return false;

		TEA tea(key, TIMES, false);
		tea.encrypt(plain, crypt);
		strCrypt += bytesToHexString(crypt, SIZE_OUT);
	}
	char cLen = src.length() % 8 + '0';
	dest = cLen + strCrypt;
	return true;
}

void usage()
{
	string usage = "\t\t#######################################  \n\
\t\t##   With all the Love from Phithon  ## \n\
\t\t##               ++++                ##  \n\
\t\t##            ++++  +++              ##  \n\
\t\t##          +++       ++++           ##  \n\
\t\t##        +++            ++          ##  \n\
\t\t##       ++++++++++++++++++++        ##  \n\
\t\t##          +            +           ##  \n\
\t\t##           +          +            ##  \n\
\t\t##            ++     +++             ##  \n\
\t\t##          ++++++++++ ++++          ##  \n\
\t\t##      +++++     ++      ++++       ##  \n\
\t\t##   +++++        ++        ++++     ##  \n\
\t\t##  +++           ++          ++++   ##  \n\
\t\t##                ++            +++  ##  \n\
\t\t##                ++                 ##  \n\
\t\t##                ++                 ##  \n\
\t\t##                ++                 ##  \n\
\t\t##                ++                 ##  \n\
\t\t#######################################	 \n\
Tea encrypt into string t00l, you can convert \n\
a string to an encrypted hex code by tea (64 repeat encode).\n\
usage: e for encode, d for decode ";
	cout << usage << endl;

}